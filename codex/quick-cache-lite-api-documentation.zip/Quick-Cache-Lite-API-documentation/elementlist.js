
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","__()"],["f","plugin()"],["c","quick_cache"],["c","quick_cache\\actions"],["c","quick_cache\\advanced_cache"],["c","quick_cache\\menu_pages"],["c","quick_cache\\plugin"],["c","quick_cache\\share"],["c","quick_cache\\version_specific_upgrade"],["f","wp_cache_postload()"],["f","wp_php53()"],["f","wp_php53_custom_notice()"],["f","wp_php53_notice()"]];
