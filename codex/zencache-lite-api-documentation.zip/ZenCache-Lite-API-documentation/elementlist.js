
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","__()"],["f","___wp_php_rv_initialize()"],["f","plugin()"],["f","wp_cache_postload()"],["f","wp_php_rv()"],["f","wp_php_rv_custom_notice()"],["f","wp_php_rv_missing()"],["f","wp_php_rv_notice()"],["c","zencache"],["c","zencache\\actions"],["c","zencache\\advanced_cache"],["c","zencache\\advanced_cache_back_compat"],["c","zencache\\menu_pages"],["c","zencache\\plugin"],["c","zencache\\share"],["c","zencache\\uninstall"],["c","zencache\\utils_feed"],["c","zencache\\version_specific_upgrade"]];
